
export default function Publicacao({ titulo }) {

    return (
        <li>{titulo}</li>
    )
}