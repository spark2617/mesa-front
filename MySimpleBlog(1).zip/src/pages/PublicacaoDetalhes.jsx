
export default function PublicacaoDetalhes() {

    /*
        Apresente 
    */
    return (
        <></>
    )
}