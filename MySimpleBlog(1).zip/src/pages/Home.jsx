
import { useState } from "react";

import Publicacao from './Publicacao';


export default function Home() {

    const [artigos, definirArtigos] = useState([
        {
            id: 1,
            title: 'ABC'
        },
        {
            id: 2,
            title: 'DEF'
        },
        {
            id: 3,
            title: 'GHI'
        }
    ]);

    return (
        <>
            <h1>Publicações</h1>
            <ul>
                {artigos.map(artigo => <Publicacao titulo={artigo.title} />)}
            </ul>
        </>
    )
}
